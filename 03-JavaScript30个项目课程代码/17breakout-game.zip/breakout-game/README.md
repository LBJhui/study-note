lesson-8:更新得分&游戏重置
