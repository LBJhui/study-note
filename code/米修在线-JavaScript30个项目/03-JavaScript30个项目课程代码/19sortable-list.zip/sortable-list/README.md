lesson-06:查验排序
