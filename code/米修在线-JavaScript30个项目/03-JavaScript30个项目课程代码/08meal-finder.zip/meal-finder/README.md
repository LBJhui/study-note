lesson-5：单个食谱的 CSS 样式&随机食谱
