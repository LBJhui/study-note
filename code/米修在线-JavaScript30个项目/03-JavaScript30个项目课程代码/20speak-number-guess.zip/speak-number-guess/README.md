lesson-4:结果验证
