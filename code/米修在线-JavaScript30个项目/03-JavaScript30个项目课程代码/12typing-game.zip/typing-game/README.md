lesson-6:难度设置
