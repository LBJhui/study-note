lesson-6:显示歌词
