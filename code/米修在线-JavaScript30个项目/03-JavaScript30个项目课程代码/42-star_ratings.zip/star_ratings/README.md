项目介绍：原生 JS 实现星级评价应用
知识点： font awesome 5，jsDOM 操作
难度：一般
